///////////////////////////////////////////////////////////
//  CircuitSolComposite.cpp
//  Implementation of the Class CircuitSolComposite
//  Created on:      27-oct.-2016 15:12:34
//  Original author: francois
///////////////////////////////////////////////////////////

#include <stdexcept>

#include "CircuitSolComposite.h"


CircuitSolComposite::CircuitSolComposite(){

}



CircuitSolComposite::~CircuitSolComposite(){

}


CircuitSolComposite::ElmCircuitSolPtr CircuitSolComposite::getSousElement(size_t index){
	return  nullptr;
}

const CircuitSolComposite::ElmCircuitSolPtr CircuitSolComposite::getSousElement(size_t index) const {
	return  nullptr;
}

int CircuitSolComposite::nombreSousElements() const {
	return 0;
}


void CircuitSolComposite::addSousElement(const ElmCircuitSolPtr& sousElem){
}

void CircuitSolComposite::addSousElement(ElmCircuitSolide* sousElem){
}

float CircuitSolComposite::getDebris(void) const {
	// Recuperer la quantite de debris maximum parmi tous les enfants
	float debrisMax = 0;
	return debrisMax;
}

void CircuitSolComposite::operer( float duree ){
}

void CircuitSolComposite::nettoyer(){
}


