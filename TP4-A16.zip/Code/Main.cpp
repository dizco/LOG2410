#include <iostream>

#include "Test_TP4.h"

int main() {
	Test_TP4 TestCorrection;

	TestCorrection.executeCompositeTest();
	TestCorrection.executeTemplateMethodTest();

	return 0;
}